# DetectoresMIMO
Detectores para Sistemas MIMO: MLD, ZF, MMSE, SD.
